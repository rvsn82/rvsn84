mod audio;
mod wasapi;
mod model;
mod gpu_auto_detect;
mod diagnostics;

use audio::{ProductionAudioEngine, WasapiConfig};
use model::Model;

use std::thread;
use std::time::Duration;

fn main() {
    println!("[MAIN] Старт...");

    // -----------------------------
    // AUDIO ENGINE
    // -----------------------------
    let mut engine = ProductionAudioEngine::new("default");

    let cfg = WasapiConfig {
        sample_rate: 48000,
        channels: 2,
        buffer_duration_ms: 10,
    };

    engine
        .start(cfg, true)
        .expect("ENGINE START FAILED");

    // -----------------------------
    // MODEL
    // -----------------------------
    let model = Model::new().expect("MODEL INIT FAILED");

    // -----------------------------
    // BUFFER
    // -----------------------------
    let mut buf = vec![0.0f32; 4096];

    println!("[MAIN] Running event loop...");

    // -----------------------------
    // FIX: CPU SPIN LOOP (важно)
    // -----------------------------
    loop {
        let (read, is_speech) = engine.read(&mut buf);

        if read == 0 {
            // ❗ FIX: убираем 100% CPU spin
            thread::sleep(Duration::from_micros(500));
            continue;
        }

        if is_speech {
            let _ = model.transcribe(&buf[..read]);
        } else {
            // ❗ тоже даём CPU отдых
            thread::sleep(Duration::from_micros(200));
        }
    }
}
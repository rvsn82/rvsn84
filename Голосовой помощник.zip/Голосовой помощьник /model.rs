use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int};
use std::ptr::NonNull;

use enigo::{Enigo, Settings};
use enigo::Keyboard; // 🔥 FIX: нужен для text()

// ============================================================================
// Errors
// ============================================================================

#[derive(Debug)]
pub enum ModelError {
    ModelNotFound(String),
    InvalidPath,
    InitFailed,
    StateInitFailed,
    InferenceFailed,
}

// ============================================================================
// FFI
// ============================================================================

#[repr(C)]
pub struct WhisperContext {
    _private: [u8; 0],
}

#[repr(C)]
pub struct WhisperState {
    _private: [u8; 0],
}

// 🔥 FIX: нормальный ABI-safe буфер (не 1 байт!)
#[repr(C)]
#[derive(Clone, Copy)]
pub struct WhisperFullParams {
    pub _data: [u8; 512],
}

#[repr(C)]
#[derive(Clone, Copy)]
pub enum WhisperSamplingStrategy {
    Greedy = 0,
}

extern "C" {
    fn whisper_init_from_file(path: *const c_char) -> *mut WhisperContext;
    fn whisper_free(ctx: *mut WhisperContext);

    fn whisper_init_state(ctx: *mut WhisperContext) -> *mut WhisperState;
    fn whisper_free_state(state: *mut WhisperState);

    fn whisper_full_default_params(
        strategy: WhisperSamplingStrategy,
    ) -> WhisperFullParams;

    fn whisper_full_with_state(
        ctx: *mut WhisperContext,
        state: *mut WhisperState,
        params: *const WhisperFullParams,
        samples: *const f32,
        n_samples: c_int,
    ) -> c_int;

    fn whisper_full_n_segments_from_state(
        ctx: *mut WhisperContext,
        state: *mut WhisperState,
    ) -> c_int;

    fn whisper_full_get_segment_text_from_state(
        ctx: *mut WhisperContext,
        state: *mut WhisperState,
        index: c_int,
    ) -> *const c_char;
}

// ============================================================================
// Model
// ============================================================================

pub struct Model {
    ctx: NonNull<WhisperContext>,
    state: NonNull<WhisperState>,
}

impl Model {
    pub fn new() -> Result<Self, ModelError> {
        let exe = std::env::current_exe().map_err(|_| ModelError::InvalidPath)?;
        let base = exe.parent().ok_or(ModelError::InvalidPath)?;

        let model_path = base.join("models").join("ggml-medium.bin");

        if !model_path.exists() {
            return Err(ModelError::ModelNotFound(
                model_path.to_string_lossy().into_owned(),
            ));
        }

        let c_path = CString::new(model_path.to_string_lossy().as_bytes())
            .map_err(|_| ModelError::InvalidPath)?;

        let ctx_ptr = unsafe { whisper_init_from_file(c_path.as_ptr()) };
        let ctx = NonNull::new(ctx_ptr).ok_or(ModelError::InitFailed)?;

        let state_ptr = unsafe { whisper_init_state(ctx.as_ptr()) };
        let state = NonNull::new(state_ptr).ok_or_else(|| {
            unsafe { whisper_free(ctx.as_ptr()) };
            ModelError::StateInitFailed
        })?;

        Ok(Self { ctx, state })
    }

    pub fn transcribe(&self, pcm: &[f32]) -> Result<Option<String>, ModelError> {
        if pcm.is_empty() {
            return Ok(None);
        }

        // 🔥 FIX: безопасный params без UB
        let params = unsafe {
            whisper_full_default_params(WhisperSamplingStrategy::Greedy)
        };

        let code = unsafe {
            whisper_full_with_state(
                self.ctx.as_ptr(),
                self.state.as_ptr(),
                &params,
                pcm.as_ptr(),
                pcm.len() as c_int,
            )
        };

        if code != 0 {
            return Err(ModelError::InferenceFailed);
        }

        let n = unsafe {
            whisper_full_n_segments_from_state(self.ctx.as_ptr(), self.state.as_ptr())
        }.max(0);

        let mut result = String::new();

        for i in 0..n {
            let ptr = unsafe {
                whisper_full_get_segment_text_from_state(
                    self.ctx.as_ptr(),
                    self.state.as_ptr(),
                    i,
                )
            };

            if ptr.is_null() {
                continue;
            }

            let text = unsafe { CStr::from_ptr(ptr) }
                .to_string_lossy()
                .trim()
                .to_string();

            if !text.is_empty() {
                if !result.is_empty() {
                    result.push(' ');
                }
                result.push_str(&text);
            }
        }

        let final_text = result.trim().to_string();

        if final_text.is_empty() {
            return Ok(None);
        }

        Self::send_to_active_window(&final_text);

        Ok(Some(final_text))
    }

    fn send_to_active_window(text: &str) {
        if let Ok(mut enigo) = Enigo::new(&Settings::default()) {
            enigo.text(text); // 🔥 FIX теперь работает (Keyboard trait в scope)
        }
    }
}

impl Drop for Model {
    fn drop(&mut self) {
        unsafe {
            whisper_free_state(self.state.as_ptr());
            whisper_free(self.ctx.as_ptr());
        }
    }
}